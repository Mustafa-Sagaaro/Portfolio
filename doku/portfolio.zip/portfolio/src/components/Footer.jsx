import React from 'react'

const Footer = () => {
    return (
        <Footer>
            C Mustafa
        </Footer>
    )
}

export default Footer