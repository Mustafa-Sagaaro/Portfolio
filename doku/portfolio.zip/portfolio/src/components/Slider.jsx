import React from 'react'
import "../utils/motion.js"
import "../styles/main.css";
import gsap from 'gsap';
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.9.1/gsap.min.js"></script>



const Slider = () => {
    return (
        <div className="Slider"></div>
    )
}




export default Slider